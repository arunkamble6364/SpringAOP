/* this class is going to have all aspect to track operation of operation class*/
package aopproject;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class TracKOperation {
	
    /*@Pointcut("execution(* Operation.m*(..))")
    public void test() {}
    
    @After("test()")
    public void MyAdvise(JoinPoint objjp)
    {
    	System.out.println("myadvise is called after execution of method name");
    	System.out.println(objjp.getSignature());
    }*/
    
  /*  @Pointcut("execution(* Operation.s*(..))")
    public void pcs() {}
    @Before("pcs()")
    public void pcsAdvise(JoinPoint objjp)
    {
    	System.out.println("myadvise is called before execution of method name");
    	System.out.println(objjp.getSignature());
    }*/
	@Pointcut("execution(* Operation.r*(..))")
    public void aroundtest() {}
    
    @Around("aroundtest()")
    public void AroundAdvise(ProceedingJoinPoint objjp) throws Throwable
    {
    	System.out.println("AroundAdvise is called before execution of method name" +objjp.getSignature());
    	for(int i=1;i<100;i++) 
    		   System.out.print(i +" " );
    	Object obj = objjp.proceed();
    	System.out.println("AroundAdvise is called after execution of method name" +objjp.getSignature());
    	
    }
    @AfterThrowing(pointcut="execution(* Operation.max*(..))",throwing="error")
    public void throwAdvice(JoinPoint objjp,Throwable error)
    {
    	System.out.println("Exception is thrown by method"+objjp.getSignature());
    	System.out.println("Exception name is"+ error);	
    }
}
