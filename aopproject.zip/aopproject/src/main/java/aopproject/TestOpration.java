package aopproject;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class TestOpration {

	public static void main(String[] args) {
	ApplicationContext context= new ClassPathXmlApplicationContext("applicationContext.xml");
	
		Operation objOP = (Operation)context.getBean("objOP");
		/*System.out.println("method msg calling");
		objOP.msg();
		System.out.println("method m1 calling");
		objOP.m1();
		System.out.println("method show is about to call");
		objOP.show();*/
		//objOP.report();
		try {
		objOP.maxage(14);
		}
		catch(Exception e) {}
		try {
			objOP.maxage(19);	
		}
		catch(Exception e) {}
		try {
		objOP.mdivide(12, 0);
		}
		catch(Exception e) {
			e.printStackTrace();
			
		}
		
	}

}
