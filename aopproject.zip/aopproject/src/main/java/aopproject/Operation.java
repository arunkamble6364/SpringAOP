package aopproject;

public class Operation {
   public void  msg()
   {	   
	 System.out.println("Hello from msg method");   
   }
   public void m1()
   {
	   System.out.println("Hello from m1 method");
   }
   public void show()
   {	   
	   System.out.println("show method is called");   
   }
   public void report()
   {
	   System.out.println("inside method report");
	   
   }
   public void maxage(int no) throws Exception
   {
	   if(no<18)
		     throw new ArithmeticException("age can not be less than 18");
	   else
		   System.out.println("You can apply for licence of bike");
   }
   public void mdivide(int a, int b) throws Exception
   {
	   if(b==0)
		   throw new ArithmeticException("No can not be 0");
	   else
		   System.out.println(a/b); 
			   
   }
}
